package org.loony.dataflow;

import java.lang.Double; 

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.extensions.avro.io.AvroIO;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.avro.Schema;
import org.apache.avro.reflect.Nullable;


public class ReadAvro {

    public static void main(String[] args) {

        PipelineOptions options = PipelineOptionsFactory.fromArgs(args).create();
        
        runProductDetails(options);

    }

        static void runProductDetails(PipelineOptions options) {

            Pipeline p = Pipeline.create(options);
    
            p.apply("ReadAvro", AvroIO.read(User.class).from("gs://my_dataflow_bucket_2610/input_data/konbert-export-327f021a9f6b4.avro"));


            Schema schema = new Schema.Parser().parse(new File("schema.avsc"));
            PCollection<GenericRecord> records =
            p.apply(AvroIO.readGenericRecords(schema).from("gs://my_bucket/path/to/records-*.avro"));

            p.run().waitUntilFinish();


        }


        public static class User {
            private String name;
            private int age;
            @Nullable
            private String address;
        
            // Constructors
            public User() {}
        
            public User(String name, int age, String address) {
                this.name = name;
                this.age = age;
                this.address = address;
            }
        
            // Getters and setters
            public String getName() {
                return name;
            }
        
            public void setName(String name) {
                this.name = name;
            }
        
            public int getAge() {
                return age;
            }
        
            public void setAge(int age) {
                this.age = age;
            }
        
            public String getAddress() {
                return address;
            }
        
            public void setAddress(String address) {
                this.address = address;
            }
        

        }    

}
